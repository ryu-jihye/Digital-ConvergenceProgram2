package org.conan.mapper;

import java.util.List;


import org.conan.domain.BookVO;

public interface BookMapper {
	
	//@Select("select * from book where bookid > 0")
	public List<BookVO> getList();

	public BookVO read(int bookid); 
}
