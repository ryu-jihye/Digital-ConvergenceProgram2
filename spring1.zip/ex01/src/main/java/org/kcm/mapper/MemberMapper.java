package org.kcm.mapper;

import org.kcm.domain.MemberVO;

public interface MemberMapper {

	public MemberVO read(String userid);
}
