package kr.co.softcampus.beans;

public class TestBean {
	
	public TestBean() {
		System.out.println("TestBean의 생성자");
	}
}
