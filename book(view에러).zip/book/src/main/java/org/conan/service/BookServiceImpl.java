package org.conan.service;

import java.util.List;

import org.conan.domain.BookVO;
import org.conan.mapper.BookMapper;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class BookServiceImpl implements BookService{
	
	private BookMapper mapper;
	
	@Override
	public BookVO get(int bookid) {
		log.info("get....." + bookid);
		return mapper.read(bookid);
	}

	@Override
	public List<BookVO> getList() {
		log.info("getList...........");
		
		return mapper.getList();
	}

}
