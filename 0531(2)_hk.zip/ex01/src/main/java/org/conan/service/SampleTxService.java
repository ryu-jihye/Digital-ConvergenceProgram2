package org.conan.service;





public interface SampleTxService {

 public void addData(String value);
	
}
