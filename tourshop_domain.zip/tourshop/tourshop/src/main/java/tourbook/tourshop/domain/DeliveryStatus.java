package tourbook.tourshop.domain;

public enum DeliveryStatus {
    READY, COMP
}
