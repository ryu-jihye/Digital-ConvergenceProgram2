package net.codejava.InventoryApp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"net.codejava.InventoryApp"})
public class InventoryAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(InventoryAppApplication.class, args);
	}
}