package tourbook.tourshop.repository;

import org.springframework.stereotype.Repository;
import tourbook.tourshop.domain.Tea;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public class TeaRepository {

    @PersistenceContext
    EntityManager em;

    public Long teasave(Tea tea) {
        em.persist(tea);
        return tea.getId();
    }

    public Tea teafind(Long id) {
        return em.find(Tea.class, id); //find값을 이용
    }
}
