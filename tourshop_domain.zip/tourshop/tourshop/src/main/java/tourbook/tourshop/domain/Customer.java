package tourbook.tourshop.domain;

import lombok.Getter;
import lombok.Setter;
import org.apache.tomcat.jni.Address;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter @Setter
public class Customer {

    @Id @GeneratedValue //엔티티 식별자 id
    @Column(name = "customer_id") //pk 컬럼명 : customer_id
    private Long userId;

    private String username;

    @Embedded
    private Address address;

    @OneToMany(mappedBy = "customer")
    private List<Order> orders = new ArrayList<>();

}
