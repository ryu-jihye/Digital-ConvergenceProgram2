package kr.co.softcampus.beans;

public interface HelloWorld {
	public void sayHello();
}
