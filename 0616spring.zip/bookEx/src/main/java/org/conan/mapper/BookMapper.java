package org.conan.mapper;

import java.util.List;

import org.conan.domain.BookVO;

public interface BookMapper {
	public List<BookVO> getList();
	public BookVO getBook(int bookId);
}
