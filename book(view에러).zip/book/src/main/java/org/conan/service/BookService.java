package org.conan.service;

import java.util.List;

import org.conan.domain.BookVO;

public interface BookService {
	public BookVO get(int bookid);
	
	public List<BookVO> getList();
}
