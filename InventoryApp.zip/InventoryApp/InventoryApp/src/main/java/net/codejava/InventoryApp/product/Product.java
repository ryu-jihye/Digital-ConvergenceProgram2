package net.codejava.InventoryApp.product;

import lombok.Getter;
import lombok.Setter;
import net.codejava.InventoryApp.category.*;

import javax.persistence.*;

@Entity
@Getter @Setter
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(length = 128, nullable = false, unique = true)
    private String name;
    private float price;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;
}
