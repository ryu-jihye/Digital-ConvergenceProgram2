package tourbook.tourshop.repository;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import tourbook.tourshop.domain.Tea;
import tourbook.tourshop.repository.TeaRepository;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import javax.persistence.EntityManager;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TeaRepositoryTest {

    @Autowired
    TeaRepository teaRepository;

    @Test
    @Transactional
    @Rollback(false)
    public void testTea() {
        Tea tea = new Tea();
        tea.setTeaname("chamomile");
        Long saveTeaId = teaRepository.teasave(tea);

        Tea findTea = teaRepository.teafind(saveTeaId);

        Assertions.assertThat(findTea.getId()).isEqualTo(tea.getId());
        Assertions.assertThat(findTea.getTeaname()).isEqualTo(tea.getTeaname());
        Assertions.assertThat(findTea).isEqualTo(tea);
    }
}