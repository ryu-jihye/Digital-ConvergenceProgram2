package kr.co.softcampus.beans;

public class HelloWorldEn implements HelloWorld{

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("HI~~~~~~~");
		
	}

}
