package tourbook.tourshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TourshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TourshopApplication.class, args);
	}

}
