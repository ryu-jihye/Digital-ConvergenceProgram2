package tourbook.tourshop.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
