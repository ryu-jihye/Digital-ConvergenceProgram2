package org.conan.domain;

import lombok.Data;

@Data//이걸 해주셔야 getter setter 자동 생성이 됩니다.
public class AttachFileDTO {
	
	private String fileName;
	private String uploadPath;
	private String uuid;
	private boolean image;
	

}
