package tourbook.tourshop.domain;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Embeddable;

@Embeddable
@Getter
public class Address {

    private String mainAddress;
    private String subAddress;
    private String zipcode;

    protected Address() {

    }

    public Address(String mainAddress, String subAddress, String zipcode) {
        this.mainAddress = mainAddress;
        this.subAddress = subAddress;
        this.zipcode = zipcode;
    }
}
