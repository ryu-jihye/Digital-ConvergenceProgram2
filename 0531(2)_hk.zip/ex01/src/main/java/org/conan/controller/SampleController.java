package org.conan.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample")
@Log4j
public class SampleController {

	@GetMapping("/all")
	public void doAll() {
		log.info("누구나오시오");
	}
	
	@GetMapping("/member")
	public void doMember() {
		log.info("로그인했다면 오시오");
	}
	
	@GetMapping("/admin")
	public void doAdmin() {
		log.info("관리자만 오시오");
	}
	
	@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_MEMBER')")
	@GetMapping("/annoMember")
	public void doMember2() {
		log.info("어노테이션이구나");
	}
	
	@Secured({"ROLE_ADMIN"})
	@GetMapping("/annoAdmin")
	public void doAdmin2() {
		log.info("어노테이션 어드민이구나");
	}
}
