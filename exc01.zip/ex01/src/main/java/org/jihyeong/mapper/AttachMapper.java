package org.jihyeong.mapper;

import org.jihyeong.domain.BoardAttachVO;

public interface AttachMapper {

	static void insert(BoardAttachVO attach) {
		// TODO Auto-generated method stub
		
	}

}
