package org.conan.sample;

import java.util.List;
import java.util.stream.IntStream;

import org.conan.domain.Criteria;
import org.conan.domain.ReplyVO;
import org.conan.mapper.ReplyMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

public class ReplyMapperTest {

	@Setter(onMethod = @__({@Autowired}))
	private ReplyMapper mapper;
	
	//게시물이 있는지 확인할 것
	private Long[] bnoArr = {1L, 2L, 8L, 9L, 10L};
	
	@Test
	public void testCreate() {
	IntStream.rangeClosed(1, 10).forEach(i -> {ReplyVO vo = new ReplyVO();
	
	//게시물 번호
	vo.setBno(bnoArr[i % 5]);
	vo.setReply("댓글 테스트" + i);
	vo.setReplyer("replyer" + i);
	mapper.insert(vo);
	});
	}
	
	@Test
	public void testRead() {
		Long targetRno = 5L;
		ReplyVO vo = mapper.read(targetRno);
		log.info(vo);
		}
	@Test
	public void testDelete() {
		Long targetRno = 43L;
		mapper.delete(targetRno);
	}
	@Test
	public void testUpdate() {
		Long targetRno = 10L;
		ReplyVO vo = mapper.read(targetRno);
		vo.setReply("Update Reply");
		int count = mapper.update(vo);
		log.info("Update Count : " + count);
	}
	@Test
	public void testList() {
		Criteria cri = new Criteria();
		List<ReplyVO> replies = mapper.getListWithPaging(cri, bnoArr[0]);
		replies.forEach(reply -> log.info(reply));
	}
	@Test
	public void testList2() {
		Criteria cri = new Criteria(1,10);
		List<ReplyVO> replies = mapper.getListWithPaging(cri, 35L);
		replies.forEach(reply->log.info(reply));
	}
	
	
	}
	

	
