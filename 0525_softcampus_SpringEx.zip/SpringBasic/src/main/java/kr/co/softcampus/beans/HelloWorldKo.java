package kr.co.softcampus.beans;

public class HelloWorldKo implements HelloWorld{

	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		System.out.println("안녕하세요");	
	}

}
