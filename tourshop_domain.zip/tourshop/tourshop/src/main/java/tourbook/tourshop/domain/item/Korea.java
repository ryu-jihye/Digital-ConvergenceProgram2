package tourbook.tourshop.domain.item;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("K")
@Getter
@Setter
public class Korea {
    private String countryName;
    private String content;
}
