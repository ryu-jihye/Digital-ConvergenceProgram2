package org.jihyeong.service;

public interface SampleTxService {

	void addData(String value);

}
