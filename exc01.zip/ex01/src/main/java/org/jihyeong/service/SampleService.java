package org.jihyeong.service;

public interface SampleService {

	Integer doAdd(String str1, String str2) throws Exception;

}
